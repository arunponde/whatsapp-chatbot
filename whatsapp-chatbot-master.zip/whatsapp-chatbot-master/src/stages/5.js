/**
 * The client is connection ended here. In 60 seconds, it'll closed.
 */
export const finalStage = {
  exec({ from, client }) {
    return;
  },
};
